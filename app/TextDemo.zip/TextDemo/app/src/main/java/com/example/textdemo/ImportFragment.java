package com.example.textdemo;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Point;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;

import java.io.IOException;

import static com.example.textdemo.MainActivity.invalidWords;


public class ImportFragment extends Fragment implements View.OnClickListener {

    ImageView imageView;
    TextView textView;
    Button btnImport;
    Button btnRotate;
    Button btnCapture;
    Bitmap bitmap = null;
    Intent intent;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_import, container, false);

        imageView = rootView.findViewById(R.id.imageId);
        //find textView
        textView = rootView.findViewById(R.id.textId);

        btnRotate = (Button) rootView.findViewById(R.id.btnRotate);
        btnImport = (Button) rootView.findViewById(R.id.btnImport);
        btnCapture = (Button) rootView.findViewById(R.id.btnCapture);
        btnCapture.setOnClickListener(this);
        btnImport.setOnClickListener(this);
        btnRotate.setOnClickListener(this);

        return rootView;
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {
            case R.id.btnImport:
                intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setType("image/*");
                startActivityForResult(intent, 101);
                break;

            case R.id.btnRotate:
                bitmap = rotateBitmap(bitmap, 90);
                imageView.setImageBitmap(bitmap);
                analyseText();
                                break;
            case R.id.btnCapture:
                intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, 102);
                break;
        }
        btnRotate.setVisibility(view.VISIBLE);
    }

    ;

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {


        if  (requestCode == 101) {
            Uri imageSelected = data.getData();

            //Context applicationContext = MainActivity.getContextOfApplication();
            //applicationContext.getContentResolver();

            try {
                bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), imageSelected);
            } catch (IOException e) {
                e.printStackTrace();
            }

            imageView.setImageBitmap(bitmap);
            analyseText();
        } else if (requestCode == 102){
            Bundle bundle = data.getExtras();
            bitmap = (Bitmap) bundle.get("data");
            imageView.setImageBitmap(bitmap);
            analyseText();
        }

    }

    private void analyseText(){
        textView.setText(null);
        InputImage image = InputImage.fromBitmap(bitmap, 0);

        TextRecognizer recognizer = TextRecognition.getClient();

        Task<Text> result =
                recognizer.process(image)
                        .addOnSuccessListener(new OnSuccessListener<Text>() {
                            @Override
                            public void onSuccess(Text visionText) {
                                for (Text.TextBlock block : visionText.getTextBlocks()) {
                                    Rect boundingBox = block.getBoundingBox();
                                    Point[] cornerPoints = block.getCornerPoints();
                                    String text = block.getText();

                                    String[] ingredients = null;
                                    ingredients = text.split("[,:.]");

                                    outputText(ingredients);


                                }
                            }

                        })
                        .addOnFailureListener(
                                new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        //Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                    }
                                });
    }

    private void outputText(String[] ingredients) {
        Boolean isTitle = false;

        for (String ingredient : ingredients) {
            isTitle = false;
            ingredient = ingredient.toUpperCase();
            textView.append("\n");
            for (int i = 0; i < invalidWords.size(); i++) {
                if (ingredient.contains(invalidWords.get(i))) {
                    ingredient = "<font color='red'>" + ingredient + "</font>";
                }
                if (ingredient.contains("INGREDIENTS")) {
                    isTitle = true;
                }
            }
            if (!isTitle) {
                textView.append(Html.fromHtml(ingredient));
            }
        }
    }

    private static Bitmap rotateBitmap(Bitmap source, float angle) {
        Matrix matrix = new Matrix();
        matrix.postRotate(angle);
        return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
    }




}