package com.example.textdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;


public class MainActivity extends AppCompatActivity {
    static ArrayList<IngredientsList> ingredientsList = new ArrayList<IngredientsList>();
    static ArrayList<String> invalidWords = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        readFile();

        BottomNavigationView bottomNavigationView = findViewById(R.id.navBar);
        NavController navController = Navigation.findNavController(this, R.id.fragment);
        NavigationUI.setupWithNavController(bottomNavigationView, navController);


        //check for permissions
        if ((checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) ||
                (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
        }
    }

    public void readFile() {
        String name;
        String type;
        String description;
        //IngredientsList[] ingredientsLists = new IngredientsList[40];

        int i = 0;
        try {
            //File myObj = new File("IngredientsList.txt");
            //Scanner myReader = new Scanner(myObj);
            BufferedReader reader = new BufferedReader(new InputStreamReader((getAssets().open("IngredientsList.txt"))));

            while (reader.ready()) {


                name = reader.readLine();
                type = reader.readLine();
                description = reader.readLine();

                ingredientsList.add(new IngredientsList(i, name, type, description));
                invalidWords.add(ingredientsList.get(i).getIngredientName().toUpperCase());
                //System.out.println(invalidWords.get(i));

                i += 1;
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }


}
